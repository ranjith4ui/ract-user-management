 
import { Table } from '../components/Table';

export const ListUser = ( ) => {

    return (
        <div className="inline-block">
            <Table />
            </div>
    )

}