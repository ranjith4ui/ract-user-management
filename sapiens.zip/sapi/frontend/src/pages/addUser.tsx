import { Form } from '../components/Forms'; 

export const AddUser = ( ) => {

    return (
        <div className="inline-block">
            
        <Form />  
        </div>
    )

}