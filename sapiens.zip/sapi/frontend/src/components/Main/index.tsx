import React, {Component} from 'react';
import {Route, Routes} from 'react-router-dom';
import { ListUser } from '../../pages/listUser';
import { AddUser } from '../../pages/addUser';  
//Create a Main Component
class Main extends Component {
    render(){
        return(
            <div>
                {/*Render Different Component based on Route*/}
                <Routes>
                <Route path="/" element={<ListUser />}/>
                <Route path="/create" element={<AddUser />}/>
                <Route path="/list" element={<ListUser />}/>
                </Routes>
            </div>
        )
    }
}
//Export The Main Component
export default Main;