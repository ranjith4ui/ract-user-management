import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import  { Form }  from './index';
import { Provider } from 'react-redux';
import store  from '../../app/store';
import userEvent from '@testing-library/user-event';

describe('<Form>', () => {

     test("Create fname", async () => {
         
        const fname = 'Testfname';
        const lname = 'Testlname';
        const email = 'test@test.ts';
        const mockLogin = jest.fn();

        const fnameInput = screen.getByRole('textbox', { name: /fname/i , hidden: true});
        userEvent.type(fnameInput, 'Testfname');

        const lnameInput = screen.getByRole('textbox', { name: /lname/i , hidden: true});
        userEvent.type(lnameInput, 'Testlname');

        const emailInput = screen.getByRole('textbox', { name: /email/i , hidden: true});
        userEvent.type(emailInput, 'test@test.ts');

        const createButton = screen.getByRole('button', { name: /^Create$/i });
        expect(createButton).not.toBeDisabled();

        // ACT
        userEvent.click(createButton);

        // ASSERT
        await expect(mockLogin).toHaveBeenCalled();
        await expect(mockLogin).toHaveBeenCalledTimes(1);
        await expect(mockLogin).toHaveBeenCalledWith("Testfname","Testlname","test@test.ts");

    });

  
});

