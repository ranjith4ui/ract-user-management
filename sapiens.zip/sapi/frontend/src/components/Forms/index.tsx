import { IUser, User } from "../../interfaces/User";
import { useDispatch, useSelector } from "react-redux";
import { UserState, setData, setUsers } from '../../features/user/userSlice';
import { UserService } from '../../services/user.service';
import { useState } from "react";
import { useNavigate } from "react-router-dom"; 

export const Form = () => {

    const navigate = useNavigate();

    const { user } = useSelector((state:{ user: UserState }) => state);
    
    const [ errorForm, setErrorForm ] = useState({
        fname: false,
        lname: false,
        email: false
    })

    const dispatch = useDispatch();

    const userService = new UserService();
  
    const setFormValue = (event:React.ChangeEvent<HTMLInputElement>) => { 
        const shouldSetValue = event.target.value.length < 110;
        if (shouldSetValue) dispatch(setData({ ... user.data, [event.target.id]: event.target.value }))
	}

    const isValidForm = ( ) => {
   
        const error = { fname: false, lname: false, email: false }

        if(!user.data.fname) error.fname = true 
        if(!user.data.lname) error.lname = true; 
        if(!user.data.email) error.email = true; 

        setErrorForm(error) 

        return error.fname || error.lname || error.email;
    }

    const onClickListUser = () => {
        navigate("/");
    }
    const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
        if(!/[a-z]/i.test(e.key)){
            e.preventDefault();
        }       
      }
    const fetchCreate = async (event:React.FormEvent<HTMLFormElement>) => {
        try {
            event.preventDefault() 
            // valid fields 
            if(isValidForm()) return null;

            const data:IUser = await userService.post(user.data)
            // for clean form
            dispatch(setData(new User()))
            // add item
            const dataArray:IUser[] = [ ... user.list ]
            dataArray.push(data)
            dispatch(setUsers(dataArray))

            navigate("/create");

        } catch (error) {
            console.log(error);
            const errors = { fname: true, lname: true, email: true }
            setErrorForm(errors);
            return null
        }
    }

    const inputCSS = ""
    const inputError =""
    
    return (
    <div >
        <button onClick={()=>onClickListUser()}>
                    List User
                </button><br/><br/>
        <form onSubmit={(e)=>fetchCreate(e)}>
            
            <div className="form-group">
                <label >First Name [Use Only Alphabet]</label>
                <input 
                    id="fname"
                    type="text" 
                    placeholder="First Name"
                    value={user.data.fname}
                    onChange={(e)=>setFormValue(e)}
                    onKeyDown={(e)=>handleKeyDown(e)}
                    className={errorForm.fname?' form-control custome-width': inputCSS +' form-control custome-width' } />
                    {errorForm.fname && <p className="text-red">Please verify</p>}  
            </div>

            <div className="form-group">
                <label>Last Name [Use Only Alphabet]</label>
                <input 
                    id="lname"
                    type="text" 
                    placeholder="Last Name"
                    value={user.data.lname}
                    onChange={(e)=>setFormValue(e)}
                    onKeyDown={(e)=>handleKeyDown(e)}
                    className={errorForm.lname?' form-control custome-width':inputCSS  +' form-control custome-width'} />
                    {errorForm.lname && <p className="text-red">Please verify</p>}  
            </div>

            <div className="form-group">
                <label>Email</label>
                <input 
                    id="email"
                    type="email" 
                    placeholder="email@email.com" 
                    value={user.data.email}
                    onChange={(e)=>setFormValue(e)}
                    className={errorForm.email?' form-control custome-width':inputCSS +' form-control custome-width' } />
                    {errorForm.email && <p className="text-red">Please verify</p>}  
            </div>
            <br/>
            <button >
                {user.data.id?"Save":"Create"}
            </button>
        </form>
    </div>
    )
}