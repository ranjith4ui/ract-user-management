import { useDispatch, useSelector } from "react-redux"
import { IUser, User } from "../../interfaces/User"
import { UserState, setData, setUsers } from "../../features/user/userSlice";
import { useEffect } from "react";
import { UserService } from "../../services/user.service";
import { useNavigate } from "react-router-dom"; 

export const Table = () => {
    
    const navigate = useNavigate();

    const { user } = useSelector((state:{ user: UserState }) => state);

    const userService = new UserService();
    
    const dispatch = useDispatch();

    const fetchData  = async () => {
        try {
            const res:IUser[] = await userService.getAll()
            dispatch(setUsers(res))
        } catch (error) {
            console.log('Error to failed load ==>',error)
        }
    }
    
    useEffect(()=>{ 
        fetchData() 
    },[ ]) 

    
    const onClickAddUser = () => {
        navigate("/create");
    }
    

    return (
        <div className="inline-block">

                <button  onClick={()=>onClickAddUser()}>
                    Add User
                </button>
                <br/><br/>

                <div className="overflow-hidden border border-gray-200 md:rounded-lg">


                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col" >
                                    First Name
                                </th>

                                <th scope="col" >
                                    Last Name
                                </th>

                                <th scope="col" >
                                    Email
                                </th>

                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {
                                user.list.map((item:IUser, i)=>{
                                    return(
                                    <tr key={i}>
                                        <td>
                                            {item.fname}
                                        </td>
                                        <td>{item.lname}</td> 
                                        <td >{item.email}</td>
                                        
                                    </tr>
                                    )
                                })
                            }
                            
                        </tbody>
                    </table>
                </div> 
        </div>  
    )
}