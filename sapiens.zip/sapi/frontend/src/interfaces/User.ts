
export interface IUser {
    id?: number | null,
    fname: string,
    lname: string,
    email: string,
    createdAt: Date | null,
    updatedAt: Date | null
}

export class User implements IUser {
    public id: null; 
    public fname: string;
    public lname: string;
    public email: string;
    public createdAt!: Date | null;
    public updatedAt!: Date | null;

    constructor(){
        this.id = null; 
        this.fname = "";
        this.lname = "";
        this.email = ""; 
        this.createdAt = null;
        this.updatedAt = null;
    }
}

