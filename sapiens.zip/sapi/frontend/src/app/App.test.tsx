import { render, screen } from '@testing-library/react';
import React from 'react';
import App from './App';
import '@testing-library/jest-dom'
import '@testing-library/jest-dom/extend-expect'
import { Provider } from 'react-redux';
import store from "../app/store";  


describe('App tests', () => {
    
    test('should contains the heading 1', () => {
            render(
                <Provider store={store}  >
                    <App />
                </Provider>
            );
        const heading = screen.getByText(/Sapiens User management/i);
        expect(heading).toBeInTheDocument()
    });
});