import { api, headerAPI } from "../configs/axios";
import { IUser } from '../interfaces/User';


export class UserService {

    private apiURL = "v1/users";

    public async getAll() {
        try {
            console.log("Consulto")
            const response = await api.get<IUser[]>(`${this.apiURL}`)
            return await response.data            
        } catch (error) {
            console.log(error)
            throw error;
        }
    }

    public async post(data:IUser) {
        try {
            const response = await api.post<IUser>(`${this.apiURL}`, data, headerAPI)
            return await response.data            
        } catch (error) {
            console.log(error)
            throw error;
        }
    }


}