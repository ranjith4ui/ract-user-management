
 module.exports = {
    "testEnvironment": "jsdom",
    moduleDirectories: ['./node_modules', 'src'],
  // other important stuff
  setupFilesAfterEnv: ['<rootDir>/src/setupTests.ts']
}